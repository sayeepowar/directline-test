$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("classpath:vehicleReg.feature");
formatter.feature({
  "name": "Functionality on Home page to see if it Accepts the correct vehicle number",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "tests for vehicle registration",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "the car registration Number \u003cvehicleReg\u003e",
  "keyword": "Given "
});
formatter.step({
  "name": "Find Vehicle button is clicked",
  "keyword": "When "
});
formatter.step({
  "name": "Verify the \u003cresult\u003e with \u003cresultString\u003e",
  "keyword": "Then "
});
formatter.step({
  "name": "compare results using \u003ccoverStartXpath\u003e \u003ccoverStart\u003e and \u003ccoverEndXpath\u003e \u003ccoverEnd\u003e",
  "keyword": "And "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "vehicleReg",
        "result",
        "resultString",
        "coverStartXpath",
        "coverStart",
        "coverEndXpath",
        "coverEnd"
      ]
    },
    {
      "cells": [
        "\"OV12UYY\"",
        "\"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[1]\"",
        "\"Result for : OV12UYY\"",
        "\"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[2]/span\"",
        "\"09 FEB 2022 : 16 : 26\"",
        "\"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[3]/span\"",
        "\"18 FEB 2022 : 23 : 59\""
      ]
    },
    {
      "cells": [
        "\"OV12UYZ\"",
        "\"/html/body/app-root/div/div/div[2]/app-dealersearch/div/div[4]\"",
        "\"Sorry record not found\"",
        "\"\"",
        "\"\"",
        "\"\"",
        "\"\""
      ]
    },
    {
      "cells": [
        "\"\"",
        "\"/html/body/app-root/div/div/div[2]/app-dealersearch/div/div[3]/form/div\"",
        "\"Please enter a valid car registration\"",
        "\"\"",
        "\"\"",
        "\"\"",
        "\"\""
      ]
    }
  ]
});
formatter.scenario({
  "name": "tests for vehicle registration",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "the car registration Number \"OV12UYY\"",
  "keyword": "Given "
});
formatter.match({
  "location": "Steps.the_car_registration_Number(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Find Vehicle button is clicked",
  "keyword": "When "
});
formatter.match({
  "location": "Steps.enter_the_Car_reg_Number()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Verify the \"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[1]\" with \"Result for : OV12UYY\"",
  "keyword": "Then "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "compare results using \"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[2]/span\" \"09 FEB 2022 : 16 : 26\" and \"//*[@id\u003d\u0027page-container\u0027]/div[4]/div[3]/span\" \"18 FEB 2022 : 23 : 59\"",
  "keyword": "And "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "tests for vehicle registration",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "the car registration Number \"OV12UYZ\"",
  "keyword": "Given "
});
formatter.match({
  "location": "Steps.the_car_registration_Number(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Find Vehicle button is clicked",
  "keyword": "When "
});
formatter.match({
  "location": "Steps.enter_the_Car_reg_Number()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Verify the \"/html/body/app-root/div/div/div[2]/app-dealersearch/div/div[4]\" with \"Sorry record not found\"",
  "keyword": "Then "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "compare results using \"\" \"\" and \"\" \"\"",
  "keyword": "And "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "tests for vehicle registration",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "the car registration Number \"\"",
  "keyword": "Given "
});
formatter.match({
  "location": "Steps.the_car_registration_Number(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Find Vehicle button is clicked",
  "keyword": "When "
});
formatter.match({
  "location": "Steps.enter_the_Car_reg_Number()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Verify the \"/html/body/app-root/div/div/div[2]/app-dealersearch/div/div[3]/form/div\" with \"Please enter a valid car registration\"",
  "keyword": "Then "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "compare results using \"\" \"\" and \"\" \"\"",
  "keyword": "And "
});
formatter.match({
  "location": "Steps.verify_the_with(String,String,String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});